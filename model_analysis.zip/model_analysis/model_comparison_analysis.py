#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Model Comparison Analysis Script
Analyze why complex models underperform simple models, with visual comparisons
"""

import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from pathlib import Path

# Configure font settings - try multiple approaches for Chinese support
plt.rcParams['figure.dpi'] = 150
sns.set_style('whitegrid')

# Try to configure Chinese fonts, fall back to English if fails
try:
    plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
except:
    pass  # If Chinese fonts not available, continue with defaults

# Results directory
results_dir = Path(__file__).parent
results_dir.mkdir(parents=True, exist_ok=True)

# ============================================================================
# 1. Model Data Definition
# ============================================================================

model_data = {
    'simple_models': [
        {
            'name': 'XGBoost',
            'type': 'Tree Model',
            'complexity': 'Simple',
            'oof_accuracy': 81.8,
            'standalone': True,
            'color': '#27AE60'
        },
        {
            'name': 'LightGBM',
            'type': 'Tree Model',
            'complexity': 'Simple',
            'oof_accuracy': 81.5,
            'standalone': True,
            'color': '#3498DB'
        },
        {
            'name': 'CatBoost',
            'type': 'Tree Model',
            'complexity': 'Simple',
            'oof_accuracy': 81.5,
            'standalone': True,
            'color': '#9B59B6'
        },
        {
            'name': 'ExtraTrees',
            'type': 'Tree Model',
            'complexity': 'Simple',
            'oof_accuracy': 81.0,
            'standalone': True,
            'color': '#E67E22'
        },
        {
            'name': 'HistGradientBoosting',
            'type': 'Tree Model',
            'complexity': 'Simple',
            'oof_accuracy': 80.8,
            'standalone': True,
            'color': '#1ABC9C'
        },
        {
            'name': 'GBDT Ensemble',
            'type': 'Ensemble',
            'complexity': 'Simple',
            'oof_accuracy': 81.87,
            'standalone': True,
            'color': '#F39C12'
        }
    ],
    'complex_models': [
        {
            'name': 'MLP Neural Network',
            'type': 'Neural Network',
            'complexity': 'Complex',
            'oof_accuracy': 80.26,
            'standalone': True,
            'color': '#E74C3C'
        },
        {
            'name': 'GBDT + MLP (LR Blend)',
            'type': 'Hybrid',
            'complexity': 'Complex',
            'oof_accuracy': 81.744,
            'standalone': False,
            'color': '#C0392B'
        },
        {
            'name': 'GBDT + MLP (w=0.10)',
            'type': 'Hybrid',
            'complexity': 'Complex',
            'oof_accuracy': 81.859,
            'standalone': False,
            'color': '#922B21'
        },
        {
            'name': 'GBDT + Isotonic Calibration',
            'type': 'Post-processing',
            'complexity': 'Complex',
            'oof_accuracy': 81.836,
            'standalone': False,
            'color': '#7B241C'
        },
        {
            'name': 'GBDT + Pseudo-Labeling',
            'type': 'Semi-supervised',
            'complexity': 'Complex',
            'oof_accuracy': 81.801,
            'standalone': False,
            'color': '#641E16'
        }
    ]
}

all_models = model_data['simple_models'] + model_data['complex_models']

# ============================================================================
# 2. Visualization Functions
# ============================================================================

def plot_model_comparison():
    """Plot model accuracy comparison"""
    
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 12))
    
    # Plot 1: All models sorted by accuracy
    sorted_models = sorted(all_models, key=lambda x: x['oof_accuracy'], reverse=True)
    names = [m['name'] for m in sorted_models]
    accuracies = [m['oof_accuracy'] for m in sorted_models]
    colors = [m['color'] for m in sorted_models]
    
    y_pos = np.arange(len(names))
    bars = ax1.barh(y_pos, accuracies, color=colors, alpha=0.8, height=0.6)
    
    # Add value labels
    for i, (bar, acc) in enumerate(zip(bars, accuracies)):
        width = bar.get_width()
        ax1.text(width + 0.05, bar.get_y() + bar.get_height()/2,
                f'{acc:.3f}%',
                va='center', fontsize=9)
    
    # Plot 1 styling
    ax1.set_yticks(y_pos)
    ax1.set_yticklabels(names, fontsize=9)
    ax1.set_xlabel('OOF Accuracy (%)', fontsize=11)
    ax1.set_title('Model Accuracy Comparison (Sorted High to Low)', fontsize=12, fontweight='bold')
    ax1.set_xlim(80, 82.2)
    ax1.invert_yaxis()  # Invert y-axis to have highest score on top
    
    # Add baseline
    baseline = max([m['oof_accuracy'] for m in model_data['simple_models'] if m['name'] == 'GBDT Ensemble'])
    ax1.axvline(x=baseline, color='red', linestyle='--', alpha=0.5, 
                label=f'Baseline (GBDT Ensemble: {baseline:.3f}%)')
    ax1.legend(loc='lower right')
    
    # Plot 2: Grouped by complexity
    simple_accs = [m['oof_accuracy'] for m in model_data['simple_models']]
    simple_names = [m['name'] for m in model_data['simple_models']]
    complex_accs = [m['oof_accuracy'] for m in model_data['complex_models']]
    
    x = np.arange(len(model_data['simple_models']))
    width = 0.35
    
    # Simple models
    bars1 = ax2.bar(x - width/2, simple_accs, width, label='Simple Models', 
                    color='#3498DB', alpha=0.7)
    
    # Complex models - separate plotting
    complex_x = np.arange(len(model_data['complex_models']))
    complex_bars = ax2.bar(np.arange(len(model_data['complex_models'])) + len(model_data['simple_models']) + 0.5,
                          complex_accs, width, label='Complex Models', 
                          color='#E74C3C', alpha=0.7)
    
    # Plot 2 styling
    ax2.set_ylabel('OOF Accuracy (%)', fontsize=11)
    ax2.set_title('Simple Models vs Complex Models - Grouped Comparison', fontsize=12, fontweight='bold')
    ax2.set_ylim(79.5, 82.5)  # Expand y-axis to give space for legend
    ax2.axhline(y=baseline, color='green', linestyle='--', alpha=0.5,
                label='GBDT Ensemble Baseline')
    
    # Set x-axis labels
    all_x_positions = list(range(len(model_data['simple_models']))) + \
                     [i + len(model_data['simple_models']) + 0.5 for i in range(len(model_data['complex_models']))]
    all_names = simple_names + [m['name'] for m in model_data['complex_models']]
    
    # Adjust x-axis ticks
    ax2.set_xticks(all_x_positions)
    ax2.set_xticklabels(all_names, rotation=45, ha='right', fontsize=8)
    
    # Add legend - upper left, won't overlap with expanded y-axis
    ax2.legend(loc='upper left', fontsize=10)
    
    plt.tight_layout()
    plt.savefig(results_dir / '01_model_accuracy_comparison.png', bbox_inches='tight', dpi=150)
    plt.close(fig)
    
    return fig


def plot_complex_simple_comparison():
    """Compare distribution of complex and simple models"""
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    # Extract data
    simple_accs = [m['oof_accuracy'] for m in model_data['simple_models']]
    complex_accs = [m['oof_accuracy'] for m in model_data['complex_models']]
    all_accs = simple_accs + complex_accs
    
    # Box plot
    data_to_plot = [simple_accs, complex_accs]
    bp = ax1.boxplot(data_to_plot, patch_artist=True, tick_labels=['Simple Models', 'Complex Models'])
    
    # Set colors
    colors = ['#3498DB', '#E74C3C']
    for patch, color in zip(bp['boxes'], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.6)
    
    ax1.set_ylabel('OOF Accuracy (%)', fontsize=11)
    ax1.set_title('Simple vs Complex Models - Accuracy Distribution (Box Plot)', fontsize=12, fontweight='bold')
    ax1.grid(axis='y', alpha=0.3)
    
    # Violin plot
    vp = ax2.violinplot(data_to_plot, showmeans=True, showmedians=True)
    
    # Set colors
    for i, pc in enumerate(vp['bodies']):
        pc.set_facecolor(colors[i])
        pc.set_alpha(0.6)
    
    ax2.set_xticks([1, 2])
    ax2.set_xticklabels(['Simple Models', 'Complex Models'])
    ax2.set_ylabel('OOF Accuracy (%)', fontsize=11)
    ax2.set_title('Simple vs Complex Models - Accuracy Distribution (Violin Plot)', fontsize=12, fontweight='bold')
    ax2.grid(axis='y', alpha=0.3)
    
    # Add value labels - simple models
    for i, acc in enumerate(simple_accs):
        ax1.plot(1, acc, 'o', color='#2980B9', markersize=6, alpha=0.8)
        ax2.plot(1, acc, 'o', color='#2980B9', markersize=6, alpha=0.8)
    
    # Complex models
    for i, acc in enumerate(complex_accs):
        ax1.plot(2, acc, 'o', color='#C0392B', markersize=6, alpha=0.8)
        ax2.plot(2, acc, 'o', color='#C0392B', markersize=6, alpha=0.8)
    
    plt.tight_layout()
    plt.savefig(results_dir / '02_simple_complex_distribution.png', bbox_inches='tight', dpi=150)
    plt.close(fig)
    
    return fig


def plot_model_performance_trend():
    """Plot model performance vs complexity"""
    
    fig, ax = plt.subplots(figsize=(12, 7))
    
    # Prepare data
    all_sorted = sorted(all_models, key=lambda x: x['oof_accuracy'])
    x = np.arange(len(all_sorted))
    y = [m['oof_accuracy'] for m in all_sorted]
    colors = [m['color'] for m in all_sorted]
    complexities = [1 if m['complexity'] == 'Simple' else 2 for m in all_sorted]
    
    # Scatter plot, size indicates complexity
    scatter = ax.scatter(x, y, s=[100 if c == 1 else 150 for c in complexities],
                        c=colors, alpha=0.7, edgecolors='black', linewidth=1)
    
    # Add connecting line
    ax.plot(x, y, '--', color='gray', alpha=0.5)
    
    # Add labels
    for i, (name, acc) in enumerate(zip(all_sorted, y)):
        ax.text(i, acc + 0.03, name['name'], ha='center', va='bottom',
                fontsize=8, rotation=30)
    
    # Plot styling
    ax.set_xlabel('Models (Sorted by Accuracy - Low to High)', fontsize=11)
    ax.set_ylabel('OOF Accuracy (%)', fontsize=11)
    ax.set_title('Model Performance vs Complexity Analysis', fontsize=12, fontweight='bold')
    ax.grid(True, alpha=0.3, linestyle='--')
    
    # Add legend
    simple_patch = mpatches.Patch(color='#3498DB', label='Simple Models')
    complex_patch = mpatches.Patch(color='#E74C3C', label='Complex Models')
    ax.legend(handles=[simple_patch, complex_patch])
    
    # Add baseline
    baseline = max([m['oof_accuracy'] for m in model_data['simple_models'] if m['name'] == 'GBDT Ensemble'])
    ax.axhline(y=baseline, color='green', linestyle='--', alpha=0.6,
               label=f'GBDT Ensemble Baseline ({baseline:.3f}%)')
    
    # Set x-axis
    ax.set_xticks(x)
    ax.set_xticklabels([m['name'] for m in all_sorted], rotation=45, ha='right', fontsize=8)
    ax.set_ylim(80, 82.2)
    
    plt.tight_layout()
    plt.savefig(results_dir / '03_performance_complexity_trend.png', bbox_inches='tight', dpi=150)
    plt.close(fig)
    
    return fig


def generate_analysis_report():
    """Generate analysis report text"""
    
    report = """
================================================================================
                    Model Comparison Analysis Report
================================================================================

1. Model Overview
--------------------------------------------------------------------------------
This project tried two categories of models:
1. Simple models: Various gradient boosting tree models and their ensembles
2. Complex models: Neural networks, hybrid models, semi-supervised learning, etc.

2. Model Accuracy Summary
--------------------------------------------------------------------------------

[Simple Models]
  Model Name               | OOF Accuracy (%) | Type
--------------------------|-----------------|---------------------
  XGBoost                 | 81.800         | Tree Model
  LightGBM                | 81.500         | Tree Model
  CatBoost                | 81.500         | Tree Model
  ExtraTrees              | 81.000         | Tree Model
  HistGradientBoosting    | 80.800         | Tree Model
  GBDT Ensemble           | 81.870         | Ensemble (Baseline)

[Complex Models]
  Model Name               | OOF Accuracy (%) | Change from Baseline
--------------------------|-----------------|---------------------
  MLP Neural Network      | 80.260         | -1.610% (Significant Drop)
  GBDT + MLP (LR Blend)   | 81.744         | -0.126% (Drop)
  GBDT + MLP (w=0.10)     | 81.859         | -0.011% (Slight Drop)
  GBDT + Isotonic Calib.  | 81.836         | -0.034% (Drop)
  GBDT + Pseudo-Labeling  | 81.801         | -0.069% (Drop)

3. Why Do Complex Models Underperform Simple Models?
--------------------------------------------------------------------------------

1. Reasons for poor MLP Neural Network performance:
   - Small dataset size: Only 8,693 training samples, insufficient for neural networks
   - Tabular data characteristics: Tree models are naturally suited for tabular data
   - Overfitting risk: Neural networks still prone to overfit despite regularization
   - Sufficient feature engineering: Manual feature engineering already extracted most information

2. Reasons for poor hybrid model performance:
   - Simple models already near performance ceiling: GBDT Ensemble at 81.87%, limited improvement space
   - Negative transfer: Adding weaker MLP model drags down overall performance
   - Lack of model diversity: MLP and GBDT predictions not different enough

3. Reasons for poor post-processing and semi-supervised learning:
   - Isotonic calibration: Alters already optimized probability distribution, introduces error
   - Pseudo-labeling: Introduces noisy samples that interfere with the model

4. Key Findings
--------------------------------------------------------------------------------
- Tree models significantly outperform neural networks on tabular data tasks
- Simple model ensemble (GBDT Ensemble) achieves best results
- Model complexity and performance are not linearly correlated
- Feature engineering importance may exceed model selection

5. Recommendations
--------------------------------------------------------------------------------
1. For current task, continue using GBDT Ensemble as primary model
2. Try further optimizing feature engineering rather than pursuing more complex models
3. If trying neural networks, consider:
   - Using more advanced architectures (TabNet, FT-Transformer, etc.)
   - Adding data augmentation or using pre-training
   - Performing more detailed hyperparameter tuning

================================================================================
Report generated: 2026-05-17
"""
    return report


def save_analysis_report():
    """Save analysis report to file"""
    report = generate_analysis_report()
    report_path = results_dir / 'model_analysis_report.txt'
    
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report)
    
    print(f"\nAnalysis report saved to: {report_path}")
    return report


def main():
    """Main function - execute all analysis and visualization"""
    print("=" * 80)
    print("Starting model comparison analysis...")
    print("=" * 80)
    
    # 1. Generate visualizations
    print("\n1. Generating model accuracy comparison chart...")
    plot_model_comparison()
    
    print("\n2. Generating simple vs complex model distribution chart...")
    plot_complex_simple_comparison()
    
    print("\n3. Generating model performance vs complexity chart...")
    plot_model_performance_trend()
    
    # 2. Generate and save report
    print("\n4. Generating analysis report...")
    report = save_analysis_report()
    
    print("\n" + "=" * 80)
    print("Analysis complete!")
    print("=" * 80)
    print("\nAnalysis report preview:")
    print(report)


if __name__ == "__main__":
    main()
